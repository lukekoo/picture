var express = require('express');
var router = express.Router();
var tester = require('../testers/tester_wrapper');

router.post('/', function(req, res, next){
    console.log(req.body);
    var body = req.body;

    if (body === undefined || body.urls === undefined) {
        res.status(400).send('Bad Request');
        return;
    }

    console.log(body.urls);
    tester.startTest(body.urls);
    res.send('respond with a resource');
 });

 module.exports = router;