const puppeteer = require('puppeteer');

exports.startTest = async function(url) {
    console.log('Start getting suspected urls...');
    const browser = await puppeteer.launch({
        //executablePath: 'google-chrome'
        //headless: false
    });
    console.log(await browser.version());
    const page = await browser.newPage();
    //await page.setUserAgent(mobileUserAgent);
    await page.goto(url);
    const hrefs = await page.$$eval('a', links=>links.map(a=>a.href));
    //console.log('raw url list: ' + hrefs.length);
    const filteredHrefs = await filterUrls(url, hrefs);
    //console.log('filtered url list: ' + filteredHrefs.length);
    await browser.close();
    return filteredHrefs;
}

function filterUrls(baseUrl, urls) {
    //urls = urls.filter(url => url !== 'javascript:;');  
    urls = urls.filter(function(url) {
        if(url === 'javascript:;') {
            return false;
        } else if(url.split('://')[1] === baseUrl.split('://')[1]) {
            return false;
        } else if(url.split('://')[1] === baseUrl.split('://')[1] + '/') {
            return false;
        } else if(url.split('://')[1] === baseUrl.split('://')[1] + '/#') {
            return false;
        }
        return true;
    });

    return urls;
}