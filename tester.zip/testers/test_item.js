class testItem {
    constructor(url, baseUrl) {
        this.url = url;
        this.baseUrl = baseUrl;
        this.reproduced = undefined;
        this.resolved = undefined;
    }

    setReproduced(reproduced) {
        this.reproduced = reproduced;
    }

    setResolved(resovled) {
        this.resolved = resovled;
    }
}

module.exports = testItem;