var suspectedUrlCrawler = require('./suspected_url_crawler');
var testItem = require('./test_item');

exports.startTest = async function(urls) {
    var result = [];
    for (var i=0; i<urls.length; i++) {
        console.log('baseUrl: ' + urls[i]);
        suspectedUrlList = await suspectedUrlCrawler.startTest(urls[i]);
        console.log('suspectedUrlList:');
        console.log(suspectedUrlList);
        for (var j=0; j<suspectedUrlList.length; j++) {
            result.push(new testItem(suspectedUrlList[j],urls[i]));
        }
        console.log(result.length);
    }
    
}